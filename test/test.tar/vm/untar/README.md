# untar
pure javascript untar
