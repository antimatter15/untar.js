bitjs: Binary Tools for JavaScript
==================================

Automatically exported from code.google.com/p/bitjs

